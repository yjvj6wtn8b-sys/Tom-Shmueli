# Voxel Wilds — Tripo Edition

A browser-based voxel island game with first-person controls, block mining/placing, a hotbar, mobile touch controls, and optional Tripo3D text-to-3D asset generation.

## What you need
- Node.js 18 or newer
- A Tripo API key (optional for playing; required for generating Tripo assets)
- Internet connection for Three.js, GLTFLoader, and Google Fonts CDN resources

## Run it
1. Extract the ZIP.
2. Install Node.js if you don't already have it.
3. Open a terminal in this folder and run `npm install`.
4. Copy `.env.example` to `.env`.
5. Paste your Tripo API key into `.env` after `TRIPO_API_KEY=`.
6. Run `npm start`.
7. Open `http://localhost:3000` in a browser.

**Keep `.env` private.** Never paste your API key into `public/app.js`, screenshots, or a public repository.

## Tripo integration
The backend uses Tripo's documented v3 API:
- `POST https://openapi.tripo3d.ai/v3/generation/text-to-model`
- `GET https://openapi.tripo3d.ai/v3/tasks/{task_id}`

Generation is asynchronous and may consume Tripo credits. Use the **✦ TRIPO ASSETS** panel to generate a tree, crystal, or boulder. Once generation succeeds, the server streams the GLB to the game without exposing your API key to the browser.

## Controls
### Desktop
- `W A S D` / arrow keys: move
- Mouse: look around (click the game to lock the pointer)
- Left click: mine a block
- Right click: place the selected block
- `1`–`8`: choose a hotbar block
- `Esc`: pause

### Touch devices
- Drag on the right/center part of the world to look
- Arrow pad: move
- MINE / PLACE: interact with blocks
- Tap hotbar slots to select a block

## Notes
- The island is generated locally using voxel geometry; Tripo is used for optional detailed props, since AI-generated meshes are not reliable replacements for the game's grid-aligned terrain blocks.
- This is a starter game, not a complete Minecraft implementation. It uses original styling and does not include Minecraft's proprietary assets.
- If Tripo changes model versions or task response fields, adjust the backend based on the current official API docs: https://developers.tripo3d.ai/en/docs/quick-start
