import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs/promises';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_BASE = 'https://openapi.tripo3d.ai/v3';
const tasks = new Map();
app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(__dirname, 'public')));

function apiKey() { return process.env.TRIPO_API_KEY?.trim(); }
function authHeaders(json = false) {
  return { Authorization: `Bearer ${apiKey()}`, ...(json ? { 'Content-Type': 'application/json' } : {}) };
}

app.get('/api/health', (_req, res) => res.json({ ok: true, tripoConfigured: Boolean(apiKey()) }));

app.post('/api/tripo/generate', async (req, res) => {
  if (!apiKey()) return res.status(503).json({ error: 'Tripo API key is not configured. Add TRIPO_API_KEY to your .env file and restart the server.' });
  const kind = String(req.body?.kind || 'tree');
  const prompts = {
    tree: 'A single stylized fantasy game tree, chunky low-poly trunk and lush clustered green leaves, clean game-ready 3D asset, centered, isolated object, no ground, no text, colorful hand-painted PBR textures',
    crystal: 'A large luminous cyan-blue fantasy crystal cluster for a voxel adventure game, faceted low-poly geometry, beautiful detailed PBR material, isolated object, no ground, no text',
    boulder: 'A stylized mossy fantasy boulder rock prop for a colorful block-building adventure game, detailed low-poly stone geometry, moss patches, game-ready PBR textures, isolated object, no ground, no text'
  };
  if (!prompts[kind]) return res.status(400).json({ error: 'Choose tree, crystal, or boulder.' });
  try {
    const response = await fetch(`${API_BASE}/generation/text-to-model`, {
      method: 'POST', headers: authHeaders(true),
      body: JSON.stringify({ prompt: prompts[kind], model: 'v3.1-20260211', texture: true, pbr: true, texture_quality: 'detailed', geometry_quality: 'detailed', auto_size: true })
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok || body.code !== 0 || !body.data?.task_id) {
      return res.status(response.status || 502).json({ error: body.message || body.suggestion || 'Tripo could not start the generation task.', details: body });
    }
    tasks.set(body.data.task_id, { kind, createdAt: Date.now() });
    res.json({ task_id: body.data.task_id, kind });
  } catch (error) {
    res.status(502).json({ error: `Could not reach Tripo: ${error.message}` });
  }
});

app.get('/api/tripo/tasks/:id', async (req, res) => {
  if (!apiKey()) return res.status(503).json({ error: 'Tripo API key is not configured.' });
  if (!tasks.has(req.params.id)) return res.status(404).json({ error: 'Task not found on this server. Start a new generation task.' });
  try {
    const response = await fetch(`${API_BASE}/tasks/${encodeURIComponent(req.params.id)}`, { headers: authHeaders() });
    const body = await response.json().catch(() => ({}));
    if (!response.ok || body.code !== 0 || !body.data) return res.status(response.status || 502).json({ error: body.message || 'Could not read Tripo task status.' });
    const task = body.data;
    res.json({ task_id: task.task_id, status: task.status, progress: task.progress ?? 0, kind: tasks.get(req.params.id).kind, error: task.error || task.message || null, hasModel: Boolean(task.output?.model_url) });
  } catch (error) {
    res.status(502).json({ error: `Could not check task: ${error.message}` });
  }
});

// Stream only a completed model URL returned by Tripo for a task created through this server.
app.get('/api/tripo/tasks/:id/model', async (req, res) => {
  if (!apiKey()) return res.status(503).json({ error: 'Tripo API key is not configured.' });
  if (!tasks.has(req.params.id)) return res.status(404).json({ error: 'Task not found.' });
  try {
    const response = await fetch(`${API_BASE}/tasks/${encodeURIComponent(req.params.id)}`, { headers: authHeaders() });
    const body = await response.json().catch(() => ({}));
    const modelUrl = body?.data?.output?.model_url;
    if (!response.ok || body.code !== 0 || body.data?.status !== 'success' || !modelUrl) return res.status(409).json({ error: 'The model is not ready yet.' });
    const parsed = new URL(modelUrl);
    if (parsed.protocol !== 'https:' || !parsed.hostname.endsWith('tripo3d.ai')) return res.status(502).json({ error: 'Tripo returned an unexpected model URL.' });
    const modelResponse = await fetch(parsed, { redirect: 'error' });
    if (!modelResponse.ok) return res.status(502).json({ error: 'Could not download the generated model.' });
    res.setHeader('Content-Type', 'model/gltf-binary');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Content-Disposition', 'inline; filename="tripo-asset.glb"');
    if (modelResponse.body) {
      const { Readable } = await import('node:stream');
      Readable.fromWeb(modelResponse.body).pipe(res);
    } else res.status(502).end();
  } catch (error) {
    res.status(502).json({ error: `Could not load model: ${error.message}` });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`Tripo Voxel Adventure running at http://localhost:${PORT}`));
